package dev.creativelogic.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import dev.creativelogic.mobile.ui.CreativeLogicApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val repository = (application as CreativeLogicApplication).repository
        val displayPreferences = dev.creativelogic.mobile.ui.DisplayPreferences(this)
        setContent { CreativeLogicApp(repository, displayPreferences) }
    }
}
