# Roadmap

Phases advance only after implementation/tests and green GitHub Actions evidence.

| Phase | Scope | Status |
| --- | --- | --- |
| 0 | Android foundation, storage wiring, tests, CI, docs | Green/installed; player-facing UX refinement pending new CI |
| 1 | Versioned typed catalog: Trigger, Tracker, Barrier | Implemented candidate; reference verification and green CI pending |
| 2 | Touch graph, semantic ports, undo/redo, autosave | Not started |
| 3 | Deterministic simulator, trace, stepping, golden vault | Not started |
| 4 | Expand twelve MVP devices one at a time with tests | Not started |
| 5 | Validation and debugging UX | Not started |
| 6 | Library/folders, thumbnails, search, .c1logic import/export | Not started |
| 7 | Graph-derived build guide | Not started |
| 8 | Passive overlay; real phone acceptance | Not started |
| 9 | Profiling, process recreation, mobile polish | Not started |

Phase 0 is a shell and not a static diagramming substitute for the intended product.
Next task: validate player UX and the Phase 1 catalog candidate through the existing
source importer and Android CI; verify reference subsets before phase completion.
Device fidelity evidence is required before advertising simulation support.

Deferred beyond MVP: cloud/community sharing, collaboration, ratings, comments,
server catalog updates, scene view, graph components, advanced team/round simulation,
interactive tutorials and tablet-specific UI.
